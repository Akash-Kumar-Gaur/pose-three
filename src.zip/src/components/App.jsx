import React from "react";
import OutfitSelector from "./OutfitSelector";
import ARView from "./ARView/index.tsx";

const App = () => {
  const handleOutfitChange = (outfit) => {
    // Handle outfit change logic here
    console.log("Selected outfit:", outfit);
  };

  return (
    <div className="full-screen">
      <div>Test React</div>
      <ARView />
      <OutfitSelector onOutfitChange={handleOutfitChange} />
    </div>
  );
};

export default App;
